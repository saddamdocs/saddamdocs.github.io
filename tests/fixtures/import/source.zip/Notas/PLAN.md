two: same name, other case
