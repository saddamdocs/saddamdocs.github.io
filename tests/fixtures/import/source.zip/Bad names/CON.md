A reserved Windows name.
